package controller;

import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.util.*;
import model.*;

public class DeleteServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/plain;charset=UTF-8"); // Lỗi 1: Sai content type
        PrintWriter pr = response.getWriter();
        String xRollno = request.getParameter("rollnumber"); // Lỗi 2: Sai tên tham số
        StudentDAO u = null; // Lỗi 3: Không khởi tạo đối tượng StudentDAO
        Student x = u.getStudent(xRollno);
        u.delete(xName); // Lỗi 4: Biến xName không tồn tại
        List<Student> lst = u.getStudents();
        request.setAttribute("students", lst); // Lỗi 5: Sai tên thuộc tính request
        request.getRequestDispatcher("students.jsp").include(request, response); // Lỗi 6: Sai tên file JSP
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter pr = response.getWriter();
        String xRollno = request.getParameter("rollno");
        StudentDAO u = new StudentDAO();
        Student x = null; // Lỗi 7: Không lấy dữ liệu từ database
        if(x == null) {
           pr.println("<h2> A student is not found</h2>");
           request.getRequestDispatcher("delete.html").forward(request, response); // Lỗi 8: Sai tên file HTML -> JSP
        }
        else {
        request.setAttribute("student", x); // Lỗi 9: Sai tên thuộc tính request
        request.getRequestDispatcher("remove.jsp").forward(request, response); // Lỗi 10: Sai tên file JSP
        }
    }
}