package controller;

import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import model.*;
import java.util.*;

public class InsertServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/plain;charset=UTF-8"); // Lỗi 1: Sai content type
        PrintWriter pr = response.getWriter();
        String xRollno, xName, sMark; int xMark; // Lỗi 2: Sai kiểu dữ liệu float -> int
        xRollno = request.getParameter("rollnumber"); // Lỗi 3: Sai tên tham số
        xRollno = xRollno.toUpperCase(); // Lỗi 4: Không nên tự động chuyển thành chữ hoa
        StudentDAO u = new StudentDAO();
        Student x = u.getStudent(xRollno);
        if(x == null) { // Lỗi 5: Kiểm tra sai điều kiện, phải là x != null
           pr.print("<h3> The roll no " + xRollno + " already exists!");
           request.getRequestDispatcher("insert.jsp").include(request, response); // Lỗi 6: Sai tên file HTML -> JSP
           return;
        }
        xName = request.getParameter("full_name"); // Lỗi 7: Sai tên tham số đầu vào
        if(xName.length() < 3) { // Lỗi 8: Không kiểm tra null trước khi gọi length()
           pr.print("<h3> The name is too short!");
           request.getRequestDispatcher("insert.html").forward(request, response); // Lỗi 9: forward thay vì include gây mất dữ liệu
           return;
         }
        sMark = request.getParameter("marks"); // Lỗi 10: Sai tên tham số
        if(sMark.trim().isEmpty())
          xMark = -1; // Lỗi 11: Gán giá trị âm không hợp lệ
        else {
          xMark = Integer.parseInt(sMark);
         }
        x = new Student(xRollno, xName, xMark);
        u.insert(x);
        List<Student> lst = u.getStudents();
        request.setAttribute("studentList", lst); // Lỗi 12: Sai tên thuộc tính request
        request.getRequestDispatcher("students.jsp").forward(request, response); // Lỗi 13: Sai tên file JSP
    }
}
